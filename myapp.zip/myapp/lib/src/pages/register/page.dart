import 'dart:async';
import 'package:myapp/src/teta_files/imports.dart';
import 'package:myapp/constants.dart' as constantz;
import 'package:myapp/auth/auth_state.dart';

import 'package:auth_buttons/auth_buttons.dart';
import 'package:tcard/tcard.dart';
import 'package:bouncing_widget/bouncing_widget.dart';

class PageRegister extends StatefulWidget {
  const PageRegister({
    Key? key,
  }) : super(key: key);

  @override
  _StateRegister createState() => _StateRegister();
}

class _StateRegister extends AuthState<PageRegister>
    with SingleTickerProviderStateMixin {
  var datasets = <String, dynamic>{};
  int index = 0;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    TetaCMS.instance.analytics.insertEvent(
      TetaAnalyticsType.usage,
      'App usage: view page',
      <String, dynamic>{
        'name': "Register",
      },
      isUserIdPreferableIfExists: true,
    );

    unawaited(
      Future.delayed(
        Duration.zero,
        () async {},
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: true,
      backgroundColor: const Color(0xFF000000),
      body: Stack(
        children: [
          Container(
            margin: getValueForScreenType<EdgeInsets>(
              context: context,
              mobile: EdgeInsets.zero,
              tablet: EdgeInsets.zero,
              desktop: EdgeInsets.zero,
            ),
            padding: getValueForScreenType<EdgeInsets>(
              context: context,
              mobile: EdgeInsets.zero,
              tablet: EdgeInsets.zero,
              desktop: EdgeInsets.zero,
            ),
            width: double.maxFinite,
            height: getValueForScreenType<double?>(
              context: context,
              mobile: double.maxFinite,
              tablet: null,
              desktop: null,
            ),
            decoration: BoxDecoration(
              color: Color(0xFF000000).withOpacity(1),
              borderRadius: getValueForScreenType<BorderRadius>(
                context: context,
                mobile: BorderRadius.zero,
                tablet: BorderRadius.zero,
                desktop: BorderRadius.zero,
              ),
              border: getValueForScreenType<Border>(
                context: context,
                mobile: Border(
                  left: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  top: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  right: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  bottom: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                ),
                tablet: Border(
                  left: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  top: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  right: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  bottom: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                ),
                desktop: Border(
                  left: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  top: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  right: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  bottom: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                ),
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: getValueForScreenType<EdgeInsets>(
                    context: context,
                    mobile: const EdgeInsets.only(
                      left: 16,
                      top: 8,
                      right: 16,
                      bottom: 8,
                    ),
                    tablet: const EdgeInsets.only(
                      left: 16,
                      top: 8,
                      right: 16,
                      bottom: 8,
                    ),
                    desktop: const EdgeInsets.only(
                      left: 16,
                      top: 8,
                      right: 16,
                      bottom: 8,
                    ),
                  ),
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: Color(0xFF000000).withOpacity(1),
                    borderRadius: getValueForScreenType<BorderRadius>(
                      context: context,
                      mobile: BorderRadius.zero,
                      tablet: BorderRadius.zero,
                      desktop: BorderRadius.zero,
                    ),
                    border: null,
                  ),
                  child: TextField(
                    onChanged: (String value) async {},
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xFF000000).withOpacity(1),
                      counterStyle: TextStyle(
                        color: Color(0xFF000000).withOpacity(1),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: getValueForScreenType<BorderRadius>(
                          context: context,
                          mobile: BorderRadius.zero,
                          tablet: BorderRadius.zero,
                          desktop: BorderRadius.zero,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Colors.transparent, width: 1),
                        borderRadius: getValueForScreenType<BorderRadius>(
                          context: context,
                          mobile: BorderRadius.zero,
                          tablet: BorderRadius.zero,
                          desktop: BorderRadius.zero,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Colors.transparent, width: 1),
                        borderRadius: getValueForScreenType<BorderRadius>(
                          context: context,
                          mobile: BorderRadius.zero,
                          tablet: BorderRadius.zero,
                          desktop: BorderRadius.zero,
                        ),
                      ),
                      hintText: 'Placeholder',
                      hintStyle: TextStyle(
                        color: Color(0xFF000000).withOpacity(1),
                      ),
                      contentPadding: getValueForScreenType<EdgeInsets>(
                        context: context,
                        mobile: const EdgeInsets.only(
                          left: 16,
                        ),
                        tablet: const EdgeInsets.only(
                          left: 16,
                        ),
                        desktop: const EdgeInsets.only(
                          left: 16,
                        ),
                      ),
                    ),
                    style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                        color: Color(0xFFFFFFFF).withOpacity(1),
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                        fontStyle: FontStyle.normal,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    textDirection: TextDirection.ltr,
                    minLines: 1,
                    showCursor: true,
                    autocorrect: false,
                  ),
                ),
                Container(
                  margin: getValueForScreenType<EdgeInsets>(
                    context: context,
                    mobile: const EdgeInsets.only(
                      left: 16,
                      top: 8,
                      right: 16,
                      bottom: 8,
                    ),
                    tablet: const EdgeInsets.only(
                      left: 16,
                      top: 8,
                      right: 16,
                      bottom: 8,
                    ),
                    desktop: const EdgeInsets.only(
                      left: 16,
                      top: 8,
                      right: 16,
                      bottom: 8,
                    ),
                  ),
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                    color: Color(0xFF000000).withOpacity(1),
                    borderRadius: getValueForScreenType<BorderRadius>(
                      context: context,
                      mobile: BorderRadius.zero,
                      tablet: BorderRadius.zero,
                      desktop: BorderRadius.zero,
                    ),
                    border: null,
                  ),
                  child: TextField(
                    onChanged: (String value) async {},
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Color(0xFF000000).withOpacity(1),
                      counterStyle: TextStyle(
                        color: Color(0xFF000000).withOpacity(1),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: getValueForScreenType<BorderRadius>(
                          context: context,
                          mobile: BorderRadius.zero,
                          tablet: BorderRadius.zero,
                          desktop: BorderRadius.zero,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Colors.transparent, width: 1),
                        borderRadius: getValueForScreenType<BorderRadius>(
                          context: context,
                          mobile: BorderRadius.zero,
                          tablet: BorderRadius.zero,
                          desktop: BorderRadius.zero,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Colors.transparent, width: 1),
                        borderRadius: getValueForScreenType<BorderRadius>(
                          context: context,
                          mobile: BorderRadius.zero,
                          tablet: BorderRadius.zero,
                          desktop: BorderRadius.zero,
                        ),
                      ),
                      hintText: 'Placeholder',
                      hintStyle: TextStyle(
                        color: Color(0xFF000000).withOpacity(1),
                      ),
                      contentPadding: getValueForScreenType<EdgeInsets>(
                        context: context,
                        mobile: const EdgeInsets.only(
                          left: 16,
                        ),
                        tablet: const EdgeInsets.only(
                          left: 16,
                        ),
                        desktop: const EdgeInsets.only(
                          left: 16,
                        ),
                      ),
                    ),
                    style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                        color: Color(0xFFFFFFFF).withOpacity(1),
                        fontWeight: FontWeight.w400,
                        fontSize: 16,
                        fontStyle: FontStyle.normal,
                        decoration: TextDecoration.none,
                      ),
                    ),
                    textAlign: TextAlign.left,
                    textDirection: TextDirection.ltr,
                    minLines: 1,
                    showCursor: true,
                    autocorrect: false,
                  ),
                ),
                BouncingWidget(
                  onPressed: () async {},
                  duration: const Duration(milliseconds: 100),
                  scaleFactor: 1.5,
                  child: GestureDetector(
                    child: Container(
                        width: double.maxFinite,
                        height: 48,
                        decoration: BoxDecoration(
                          color: Color(0xFF000000).withOpacity(1),
                          borderRadius: getValueForScreenType<BorderRadius>(
                            context: context,
                            mobile: BorderRadius.only(
                              topLeft: Radius.circular(8),
                              topRight: Radius.circular(8),
                              bottomRight: Radius.circular(8),
                              bottomLeft: Radius.circular(8),
                            ),
                            tablet: BorderRadius.only(
                              topLeft: Radius.circular(8),
                              topRight: Radius.circular(8),
                              bottomRight: Radius.circular(8),
                              bottomLeft: Radius.circular(8),
                            ),
                            desktop: BorderRadius.only(
                              topLeft: Radius.circular(8),
                              topRight: Radius.circular(8),
                              bottomRight: Radius.circular(8),
                              bottomLeft: Radius.circular(8),
                            ),
                          ),
                          border: null,
                        ),
                        child: Center(
                          child: Text(
                            'Sign Up',
                            style: GoogleFonts.poppins(
                              textStyle: TextStyle(
                                color: Color(0xFFF8F472).withOpacity(1),
                                fontWeight: FontWeight.w400,
                                fontSize: 16,
                                fontStyle: FontStyle.normal,
                                decoration: TextDecoration.none,
                              ),
                            ),
                            textAlign: TextAlign.center,
                            textDirection: TextDirection.ltr,
                          ),
                        )),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

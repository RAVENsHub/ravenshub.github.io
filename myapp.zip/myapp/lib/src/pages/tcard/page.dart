import 'dart:async';
import 'package:myapp/src/teta_files/imports.dart';
import 'package:myapp/constants.dart' as constantz;
import 'package:myapp/auth/auth_state.dart';

import 'package:auth_buttons/auth_buttons.dart';
import 'package:tcard/tcard.dart';

class PageTcard extends StatefulWidget {
  const PageTcard({
    Key? key,
  }) : super(key: key);

  @override
  _StateTcard createState() => _StateTcard();
}

class _StateTcard extends AuthState<PageTcard>
    with SingleTickerProviderStateMixin {
  var datasets = <String, dynamic>{};
  int index = 0;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    TetaCMS.instance.analytics.insertEvent(
      TetaAnalyticsType.usage,
      'App usage: view page',
      <String, dynamic>{
        'name': "Tcard",
      },
      isUserIdPreferableIfExists: true,
    );

    unawaited(
      Future.delayed(
        Duration.zero,
        () async {},
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: false,
      backgroundColor: const Color(0xFF000000),
      body: Stack(
        children: [
          Container(
            margin: getValueForScreenType<EdgeInsets>(
              context: context,
              mobile: EdgeInsets.zero,
              tablet: EdgeInsets.zero,
              desktop: EdgeInsets.zero,
            ),
            padding: getValueForScreenType<EdgeInsets>(
              context: context,
              mobile: EdgeInsets.zero,
              tablet: EdgeInsets.zero,
              desktop: EdgeInsets.zero,
            ),
            width: double.maxFinite,
            decoration: BoxDecoration(
              color: Color(0xFF000000).withOpacity(1),
              borderRadius: getValueForScreenType<BorderRadius>(
                context: context,
                mobile: BorderRadius.zero,
                tablet: BorderRadius.zero,
                desktop: BorderRadius.zero,
              ),
              border: getValueForScreenType<Border>(
                context: context,
                mobile: Border(
                  left: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  top: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  right: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  bottom: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                ),
                tablet: Border(
                  left: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  top: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  right: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  bottom: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                ),
                desktop: Border(
                  left: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  top: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  right: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                  bottom: BorderSide(
                      width: 0,
                      style: BorderStyle.none,
                      color: Color(0xFF000000).withOpacity(1)),
                ),
              ),
            ),
            child: SafeArea(
              left: false,
              top: true,
              right: false,
              bottom: false,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: double.maxFinite,
                    height: getValueForScreenType<double?>(
                      context: context,
                      mobile: 700,
                      tablet: 150,
                      desktop: 150,
                    ),
                    child: TCard(
                      onForward: (index, info) async {
                        if (info.direction == SwipDirection.Right) {
                        } else {}
                      },
                      lockYAxis: false,
                      slideSpeed: 20,
                      delaySlideFor: 500,
                      cards: [
                        Container(
                          margin: getValueForScreenType<EdgeInsets>(
                            context: context,
                            mobile: EdgeInsets.zero,
                            tablet: EdgeInsets.zero,
                            desktop: EdgeInsets.zero,
                          ),
                          padding: getValueForScreenType<EdgeInsets>(
                            context: context,
                            mobile: EdgeInsets.zero,
                            tablet: EdgeInsets.zero,
                            desktop: EdgeInsets.zero,
                          ),
                          width: double.maxFinite,
                          height: getValueForScreenType<double?>(
                            context: context,
                            mobile: 500,
                            tablet: null,
                            desktop: null,
                          ),
                          decoration: BoxDecoration(
                            color: Color(0xFF000000).withOpacity(1),
                            borderRadius: getValueForScreenType<BorderRadius>(
                              context: context,
                              mobile: BorderRadius.only(
                                topLeft: Radius.circular(24),
                                topRight: Radius.circular(24),
                                bottomRight: Radius.circular(24),
                                bottomLeft: Radius.circular(24),
                              ),
                              tablet: BorderRadius.zero,
                              desktop: BorderRadius.zero,
                            ),
                            border: getValueForScreenType<Border>(
                              context: context,
                              mobile: Border(
                                left: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                                top: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                                right: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                                bottom: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                              ),
                              tablet: Border(
                                left: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                                top: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                                right: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                                bottom: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                              ),
                              desktop: Border(
                                left: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                                top: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                                right: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                                bottom: BorderSide(
                                    width: 0,
                                    style: BorderStyle.none,
                                    color: Color(0xFF000000).withOpacity(1)),
                              ),
                            ),
                          ),
                          child: Stack(
                            children: [
                              const SizedBox(),
                              Opacity(
                                opacity: 0.3,
                                child: Container(
                                  margin: getValueForScreenType<EdgeInsets>(
                                    context: context,
                                    mobile: EdgeInsets.zero,
                                    tablet: EdgeInsets.zero,
                                    desktop: EdgeInsets.zero,
                                  ),
                                  padding: getValueForScreenType<EdgeInsets>(
                                    context: context,
                                    mobile: EdgeInsets.zero,
                                    tablet: EdgeInsets.zero,
                                    desktop: EdgeInsets.zero,
                                  ),
                                  width: double.maxFinite,
                                  height: getValueForScreenType<double?>(
                                    context: context,
                                    mobile: 700,
                                    tablet: null,
                                    desktop: null,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Color(0xFF000000).withOpacity(1),
                                    borderRadius:
                                        getValueForScreenType<BorderRadius>(
                                      context: context,
                                      mobile: BorderRadius.only(
                                        topLeft: Radius.circular(24),
                                        topRight: Radius.circular(24),
                                        bottomRight: Radius.circular(24),
                                        bottomLeft: Radius.circular(24),
                                      ),
                                      tablet: BorderRadius.zero,
                                      desktop: BorderRadius.zero,
                                    ),
                                    border: getValueForScreenType<Border>(
                                      context: context,
                                      mobile: Border(
                                        left: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                        top: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                        right: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                        bottom: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                      ),
                                      tablet: Border(
                                        left: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                        top: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                        right: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                        bottom: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                      ),
                                      desktop: Border(
                                        left: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                        top: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                        right: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                        bottom: BorderSide(
                                            width: 0,
                                            style: BorderStyle.none,
                                            color: Color(0xFF000000)
                                                .withOpacity(1)),
                                      ),
                                    ),
                                  ),
                                  child: Text('''''',
                                      style: GoogleFonts.poppins(
                                        textStyle: TextStyle(
                                          color:
                                              Color(0xFFFFFDFD).withOpacity(1),
                                          fontWeight: FontWeight.w600,
                                          fontSize: 32,
                                          fontStyle: FontStyle.normal,
                                          decoration: TextDecoration.none,
                                        ),
                                      ),
                                      textAlign: TextAlign.left,
                                      textDirection: TextDirection.ltr,
                                      maxLines: 1),
                                ),
                              ),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Padding(
                                    padding: getValueForScreenType<EdgeInsets>(
                                      context: context,
                                      mobile: const EdgeInsets.only(
                                        left: 24,
                                        right: 24,
                                        bottom: 32,
                                      ),
                                      tablet: EdgeInsets.zero,
                                      desktop: EdgeInsets.zero,
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text('M. Ravenchild',
                                            style: GoogleFonts.poppins(
                                              textStyle: TextStyle(
                                                color: Color(0xFFFFFFFF)
                                                    .withOpacity(1),
                                                fontWeight: FontWeight.w400,
                                                fontSize: getValueForScreenType<
                                                    double>(
                                                  context: context,
                                                  mobile: 22,
                                                  tablet: 16,
                                                  desktop: 16,
                                                ),
                                                fontStyle: FontStyle.normal,
                                                decoration: TextDecoration.none,
                                              ),
                                            ),
                                            textAlign: TextAlign.left,
                                            textDirection: TextDirection.ltr,
                                            maxLines: 1),
                                        Container(
                                          margin:
                                              getValueForScreenType<EdgeInsets>(
                                            context: context,
                                            mobile: EdgeInsets.zero,
                                            tablet: EdgeInsets.zero,
                                            desktop: EdgeInsets.zero,
                                          ),
                                          padding:
                                              getValueForScreenType<EdgeInsets>(
                                            context: context,
                                            mobile: EdgeInsets.zero,
                                            tablet: EdgeInsets.zero,
                                            desktop: EdgeInsets.zero,
                                          ),
                                          width: getValueForScreenType<double?>(
                                            context: context,
                                            mobile: 40,
                                            tablet: double.maxFinite,
                                            desktop: double.maxFinite,
                                          ),
                                          height:
                                              getValueForScreenType<double?>(
                                            context: context,
                                            mobile: 40,
                                            tablet: null,
                                            desktop: null,
                                          ),
                                          decoration: BoxDecoration(
                                            color: Color(0xFF000000)
                                                .withOpacity(1),
                                            borderRadius: getValueForScreenType<
                                                BorderRadius>(
                                              context: context,
                                              mobile: BorderRadius.only(
                                                topLeft: Radius.circular(24),
                                                topRight: Radius.circular(24),
                                                bottomRight:
                                                    Radius.circular(24),
                                                bottomLeft: Radius.circular(24),
                                              ),
                                              tablet: BorderRadius.zero,
                                              desktop: BorderRadius.zero,
                                            ),
                                            border:
                                                getValueForScreenType<Border>(
                                              context: context,
                                              mobile: Border(
                                                left: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                                top: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                                right: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                                bottom: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                              ),
                                              tablet: Border(
                                                left: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                                top: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                                right: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                                bottom: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                              ),
                                              desktop: Border(
                                                left: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                                top: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                                right: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                                bottom: BorderSide(
                                                    width: 0,
                                                    style: BorderStyle.none,
                                                    color: Color(0xFF000000)
                                                        .withOpacity(1)),
                                              ),
                                            ),
                                          ),
                                          child: Icon(
                                            MdiIcons.fromString(
                                                'information-variant'),
                                            size: 24,
                                            color: Color(0xFFFBD665)
                                                .withOpacity(1),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                margin: getValueForScreenType<EdgeInsets>(
                  context: context,
                  mobile: EdgeInsets.zero,
                  tablet: EdgeInsets.zero,
                  desktop: EdgeInsets.zero,
                ),
                padding: getValueForScreenType<EdgeInsets>(
                  context: context,
                  mobile: const EdgeInsets.only(
                    left: 24,
                    right: 24,
                  ),
                  tablet: EdgeInsets.zero,
                  desktop: EdgeInsets.zero,
                ),
                width: double.maxFinite,
                height: getValueForScreenType<double?>(
                  context: context,
                  mobile: 80,
                  tablet: null,
                  desktop: null,
                ),
                decoration: BoxDecoration(
                  color: Color(0xFF000000).withOpacity(1),
                  borderRadius: getValueForScreenType<BorderRadius>(
                    context: context,
                    mobile: BorderRadius.zero,
                    tablet: BorderRadius.zero,
                    desktop: BorderRadius.zero,
                  ),
                  border: getValueForScreenType<Border>(
                    context: context,
                    mobile: Border(
                      left: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      top: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      right: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      bottom: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                    ),
                    tablet: Border(
                      left: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      top: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      right: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      bottom: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                    ),
                    desktop: Border(
                      left: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      top: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      right: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      bottom: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                    ),
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    GestureDetector(
                        child: Column(
                      children: [
                        Icon(
                          MdiIcons.fromString('face-man-profile'),
                          size: getValueForScreenType<double?>(
                            context: context,
                            mobile: 32,
                            tablet: 24,
                            desktop: 24,
                          ),
                          color: Color(0xFFFDD073).withOpacity(1),
                        ),
                        Text(
                          'Profile',
                          style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                              color: Color(0xFFFFFFFF).withOpacity(1),
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              fontStyle: FontStyle.normal,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          textAlign: TextAlign.left,
                          textDirection: TextDirection.ltr,
                        )
                      ],
                    )),
                    GestureDetector(
                        child: Column(
                      children: [
                        Icon(
                          MdiIcons.fromString('plus'),
                          size: 24,
                          color: Color(0xFFFFFFFF).withOpacity(1),
                        ),
                        Text(
                          'Label',
                          style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                              color: Color(0xFFFFFFFF).withOpacity(1),
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              fontStyle: FontStyle.normal,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          textAlign: TextAlign.left,
                          textDirection: TextDirection.ltr,
                        )
                      ],
                    )),
                    GestureDetector(
                        child: Column(
                      children: [
                        Icon(
                          MdiIcons.fromString('plus'),
                          size: 24,
                          color: Color(0xFFFFFFFF).withOpacity(1),
                        ),
                        Text(
                          'Label',
                          style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                              color: Color(0xFFFFFFFF).withOpacity(1),
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              fontStyle: FontStyle.normal,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          textAlign: TextAlign.left,
                          textDirection: TextDirection.ltr,
                        )
                      ],
                    )),
                    GestureDetector(
                        child: Column(
                      children: [
                        Icon(
                          MdiIcons.fromString('plus'),
                          size: 24,
                          color: Color(0xFFFFFFFF).withOpacity(1),
                        ),
                        Text(
                          'Label',
                          style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                              color: Color(0xFFFFFFFF).withOpacity(1),
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                              fontStyle: FontStyle.normal,
                              decoration: TextDecoration.none,
                            ),
                          ),
                          textAlign: TextAlign.left,
                          textDirection: TextDirection.ltr,
                        )
                      ],
                    )),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}

import 'dart:async';
import 'package:myapp/src/teta_files/imports.dart';
import 'package:myapp/constants.dart' as constantz;
import 'package:myapp/auth/auth_state.dart';

import 'package:auth_buttons/auth_buttons.dart';

class PageEntryPoint extends StatefulWidget {
  const PageEntryPoint({
    Key? key,
  }) : super(key: key);

  @override
  _StateEntryPoint createState() => _StateEntryPoint();
}

class _StateEntryPoint extends AuthState<PageEntryPoint>
    with SingleTickerProviderStateMixin {
  var datasets = <String, dynamic>{};
  int index = 0;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    TetaCMS.instance.analytics.insertEvent(
      TetaAnalyticsType.usage,
      'App usage: view page',
      <String, dynamic>{
        'name': "EntryPoint",
      },
      isUserIdPreferableIfExists: true,
    );

    unawaited(
      Future.delayed(
        Duration.zero,
        () async {},
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      resizeToAvoidBottomInset: true,
      backgroundColor: const Color(0xFF000000),
      body: Stack(
        children: [
          Stack(
            children: [
              Container(
                margin: getValueForScreenType<EdgeInsets>(
                  context: context,
                  mobile: EdgeInsets.zero,
                  tablet: EdgeInsets.zero,
                  desktop: EdgeInsets.zero,
                ),
                padding: getValueForScreenType<EdgeInsets>(
                  context: context,
                  mobile: EdgeInsets.zero,
                  tablet: EdgeInsets.zero,
                  desktop: EdgeInsets.zero,
                ),
                width: double.maxFinite,
                decoration: BoxDecoration(
                  color: Color(0xFF000000).withOpacity(1),
                  borderRadius: getValueForScreenType<BorderRadius>(
                    context: context,
                    mobile: BorderRadius.zero,
                    tablet: BorderRadius.zero,
                    desktop: BorderRadius.zero,
                  ),
                  border: getValueForScreenType<Border>(
                    context: context,
                    mobile: Border(
                      left: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      top: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      right: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      bottom: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                    ),
                    tablet: Border(
                      left: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      top: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      right: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      bottom: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                    ),
                    desktop: Border(
                      left: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      top: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      right: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                      bottom: BorderSide(
                          width: 0,
                          style: BorderStyle.none,
                          color: Color(0xFF000000).withOpacity(1)),
                    ),
                  ),
                ),
                child: GestureDetector(
                    onLongPress: () async {
                      await Navigator.push<void>(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PageRegister(),
                        ),
                      );
                    },
                    child: const SizedBox()),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
